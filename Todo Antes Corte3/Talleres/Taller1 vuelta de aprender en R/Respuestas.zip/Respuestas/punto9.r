#no encontré el archivo geyser.txt , espero que eso se pueda solucionar en clase
