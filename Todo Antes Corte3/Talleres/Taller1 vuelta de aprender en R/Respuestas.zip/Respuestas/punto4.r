vector = c() 
for(i in 1:4){
    vector <- c(vector , 0.5)
}

for(i in 1:4){
    vector <- c(vector , 1.5)
}

for(i in 1:4){
    vector <- c(vector , 3)
}
print(vector)